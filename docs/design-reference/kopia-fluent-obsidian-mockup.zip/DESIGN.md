---
name: Kopia Fluent Obsidian
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c0c7d4'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8a919e'
  outline-variant: '#404752'
  surface-tint: '#a3c9ff'
  primary: '#a3c9ff'
  on-primary: '#00315c'
  primary-container: '#0078d4'
  on-primary-container: '#ffffff'
  inverse-primary: '#0060ab'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#4ae176'
  on-tertiary: '#003915'
  tertiary-container: '#00893c'
  on-tertiary-container: '#ffffff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d3e3ff'
  primary-fixed-dim: '#a3c9ff'
  on-primary-fixed: '#001c39'
  on-primary-fixed-variant: '#004883'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display:
    fontFamily: Segoe UI Variable
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Segoe UI Variable
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Segoe UI Variable
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Segoe UI Variable
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Segoe UI Variable
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-md:
    fontFamily: Segoe UI Variable
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Segoe UI Variable
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Segoe UI Variable
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Segoe UI Variable
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 2px
  space-xs: 4px
  space-sm: 8px
  space-md: 12px
  space-lg: 16px
  space-xl: 20px
  space-2xl: 24px
  space-3xl: 32px
  space-4xl: 48px
  sidebar-width: 260px
  inspector-width: 340px
  window-min-width: 960px
  window-min-height: 640px
---

## Brand & Style

The design system establishes a high-performance, native Windows 11 desktop experience engineered for data resilience, silent background execution, and immediate clarity during mission-critical snapshot and restore operations. It addresses IT power users, homelab operators, and storage administrators who expect absolute reliability without visual noise or intrusive friction.

The visual direction merges **Windows 11 Fluent 2** conventions with an architectural dark-slate aesthetic. The interface emphasizes:
- **Materiality & Translucency:** Layered Mica and Acrylic optical models that anchor desktop depth without compromising readability.
- **Precision Engineering:** Monoline strokes, deliberate geometry, and micro-telemetry data presented with structural hierarchy.
- **Calm Authority:** Muted slate backdrops accented by vivid, purposeful cobalt signals that illuminate only when action, progression, or state changes occur.

## Colors

The palette leverages a deep slate-navy scale paired with native Windows 11 high-saturation accents to preserve optical ergonomics across prolonged desktop sessions.

### Functional Roles
- **Primary Accent (`#0078D4` / `#2563EB` hover):** Reserved strictly for primary task initiations (e.g., *Snapshot Now*, *Mount Repository*), focused interactive states, and active navigation indicators.
- **Secondary / Telemetry Accent (`#38BDF8`):** Emitted across transfer speed throughput, cryptographic verification rates, dynamic progress rings, and focal metadata.
- **State Indicators:**
  - **Success (`#22C55E`):** Verified snapshots, healthy snapshot policies, and connected cloud object stores.
  - **Warning (`#F59E0B`):** Pruning deferred, rate limit warnings, or repository compaction required.
  - **Critical (`#EF4444`):** Snapshot read errors, failed authentication, or corrupted blob alerts.
- **Neutral Foundations:**
  - **Canvas Base / Mica Base (`#0F172A`):** Low-luminance root desktop window frame.
  - **Card / Surface Layer (`#1E293B` at 70–85% alpha):** Acrylic and elevated component backdrop.
  - **Stroke / Sub-surface (`#334155` at 50% alpha):** Precision separator and frosted perimeter definition.
  - **Text High-Emphasis (`#F8FAFC`):** Primary data points, paths, and labels.
  - **Text Muted (`#94A3B8`):** Secondary metadata, elapsed timestamps, and hash identifiers.

## Typography

The type scale relies natively on **Segoe UI Variable** (with fallback to system Segoe UI / Inter) utilizing its variable optical sizing axes (`opsz` Text and Display) for maximum render sharpness on subpixel DirectWrite engines. 

- **Numeric & Telemetry Layout:** All transfer metrics, time-to-completion, hash strings, and data capacities use tabular figure settings (`tnum`) to eliminate micro-jittering during live backup runs.
- **Code & Paths:** Source paths, object IDs, and encryption keys resolve through **JetBrains Mono** at optical level `code-sm` to maintain strict alignment and avoid character ambiguity (0 vs O, 1 vs l).
- **Hierarchy:** Section headers enforce `headline-md` paired with a subdued `body-sm` description to retain compact vertical efficiency across desktop dashboards.

## Layout & Spacing

The layout is built upon an 8-point base grid (with a 4-point micro sub-grid for badges, telemetry indicators, and compact list items).

### Structural Architecture
- **Window Shell:** Divided into three functional horizontal bands:
  1. **Fluent Titlebar (32px / 40px):** Drag-safe region with integrated breadcrumbs, repository switcher, and native min/max/close controls.
  2. **Navigation Rail / Sidebar (260px fixed width):** Host to repository roots, policies, snapshot timelines, and system logs.
  3. **Work Canvas (Fluid flexible width):** Grid-based or two-pane split with an optional contextual Inspector Panel (340px fixed width) for individual snapshot manifests.
- **Rhythm & Padding:** Interior card padding strictly maintains `space-lg` (16px) or `space-xl` (20px). Compact tables and telemetry list rows clamp vertical heights to `36px` to prioritize information density.

## Elevation & Depth

Visual depth follows the Windows 11 Fluent 2 layered material architecture, using subtle transparency, inner borders, and ambient light distribution instead of heavy drop shadows.

### Material Stack
1. **Desktop Background (Mica / Mica Alt):** Employs OS-tinted base layer (`#0F172A` at 90% opacity over system desktop compositor), giving the window contextual warmth without high GPU overhead.
2. **Surface Containers (Acrylic Card):** Background of `rgba(30, 41, 59, 0.72)` combined with a `backdrop-filter: blur(24px) saturate(140%)`.
3. **Inner Stroke / Frosted Edge:** A 1px continuous border around all elevated surfaces:
   - Top and left edge: `rgba(255, 255, 255, 0.08)` (subtle overhead specular reflection).
   - Bottom and right edge: `rgba(255, 255, 255, 0.03)` (ambient occlusion).
4. **Shadow Model:**
   - **Resting Card:** `0 1px 2px rgba(0, 0, 0, 0.24)`
   - **Hover / Interactive Card:** `0 4px 12px rgba(0, 0, 0, 0.36), 0 0 0 1px rgba(56, 189, 248, 0.25)`
   - **Flyout / Modal Sheet:** `0 12px 32px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1)`

## Shapes

The design system embraces Windows 11 standard geometry:
- **Root Cards & Main Containers:** Standardized on `rounded-xl` (12px / 0.75rem in desktop Fluent specifications, conforming to tier-2 curvature tokens).
- **Buttons, Text Inputs, and Dropdowns:** Standardized on `rounded-md` (6px) to maintain functional, crisp precision.
- **Telemetry Pills, Status Dots, and Filter Chips:** Fully rounded capsule/pill contours (`9999px`) to distinguish actionable filters from data-entry surfaces.
- **Focus Rings:** Distinct 2px solid `#38BDF8` ring with a 2px offset border (`rgba(15, 23, 42, 1)`) respecting Windows accessibility and keyboard navigation standards.

## Components

### Action Controls (Buttons)
- **Primary Action Button:**
  - Background: Solid accent `#0078D4` with top border highlight `rgba(255, 255, 255, 0.15)`.
  - Hover: `#2563EB`, scale: none, elevation increase via `0 2px 6px rgba(0, 120, 212, 0.35)`.
  - Active: `#1D4ED8`, brightness down 5%.
- **Subtle / Ghost Button:**
  - Background: Transparent; hover state engages `rgba(255, 255, 255, 0.05)` with `rounded-md`.
- **Compound Action Bar:**
  - Split button for operations like *Snapshot Now* (primary trigger) paired with a dropdown chevron (for *Dry Run*, *Estimate Size*, *Exclude Rules*).

### Telemetry Badges & Chips
- **Transfer Metric Badges:**
  - Structure: Inline-flex container, `rounded-full`, padding `2px 8px`.
  - Style: Tinted dark backdrop `rgba(56, 189, 248, 0.1)` with a border `rgba(56, 189, 248, 0.2)`. Text renders in `label-sm` using `#38BDF8`.
- **Deduplication / Compression Indicator:**
  - Displays dynamic ratios (e.g., `3.42x`, `-68%`) with high-contrast neutral backgrounds and a sub-surface specular border.

### Status Indicators
- **State Dots:**
  - 8px circular anchor. When active during snapshot sync, uses a pinging animated concentric aura (`rgba(34, 197, 94, 0.3)`).
- **Progress Ring / Fluent Bar:**
  - Indeterminate: Smooth flowing linear gradient (`#0078D4` to `#38BDF8`).
  - Determinate: 4px track (`rgba(255, 255, 255, 0.08)`) with dynamic track fill in `#0078D4`, terminating with a soft neon glow cap on active execution.

### Cards & Group Rows
- **Snapshot Snapshot Card:**
  - Frosted Acrylic background, `rounded-xl` corners, 16px internal padding.
  - Header displays repository path in `headline-sm`, right-aligned status badge, and an expandable sub-tree showing hash IDs, compression ratio, snapshot duration, and deduplicated block counts.
- **Interactive List Items:**
  - Alternating rows avoid striping; state changes occur strictly via `rgba(255, 255, 255, 0.04)` hover fills and a persistent 3px left-edge accent bar (`#0078D4`) on selected items.

### Form Inputs
- **Directory Path Selector & Inputs:**
  - Height: 32px; background: `rgba(15, 23, 42, 0.6)`; border: 1px solid `rgba(255, 255, 255, 0.1)`. Bottom edge features a 1px baseline accent stroke on focus (`#0078D4`).